# calculate frequency of inversion-associated alleles across samples, based on Kapun et al 2016 coordinates

setwd("/raid10/mshpak/MuseumFlies/Inversions/Kapun")

Inv_2Lt = read.csv("In2Lt_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_2RNs = read.csv("In2RNs_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_3LP = read.csv("In3LP_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_3RC = read.csv("In3RC_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_3RK = read.csv("In3RK_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_3RMo = read.csv("In3RMo_fixeddiff_kapun.txt", header=FALSE, sep='\t')
Inv_3RPayne = read.csv("In3RPayne_fixeddiff_kapun.txt", header=FALSE, sep='\t')

Kapun_Coords_2Lt = Inv_2Lt[,3]
New_Coords_2Lt = Kapun_Coords_2Lt - 1

Kapun_Coords_2RNs = Inv_2RNs[,3]
New_Coords_2RNs = Kapun_Coords_2RNs - 1

Kapun_Coords_3LP = Inv_3LP[,3]
New_Coords_3LP = Kapun_Coords_3LP - 1

Kapun_Coords_3RC = Inv_3RC[,3]
New_Coords_3RC = Kapun_Coords_3RC - 1

Kapun_Coords_3RMo = Inv_3RMo[,3]
New_Coords_3RMo = Kapun_Coords_3RMo - 1

Kapun_Coords_3RPayne = Inv_3RPayne[,3]
New_Coords_3RPayne = Kapun_Coords_3RPayne - 1

setwd("/raid10/mshpak/MuseumFlies/Counts")

Counts_FR_2L = read.csv("AllCounts_Lyon_Chr2L.txt", header=FALSE, sep='\t')
Counts_Lund_2L = read.csv("AllCounts_ModernLund_Chr2L.txt", header=FALSE, sep='\t')
Counts_1800_2L = read.csv("AllCounts_Nineteenth_Chr2L.txt", header=FALSE, sep='\t')
Counts_1900_2L = read.csv("AllCounts_Twentieth_Chr2L.txt", header=FALSE, sep='\t')

Counts_FR_3R = read.csv("AllCounts_Lyon_Chr3R.txt", header=FALSE, sep='\t')
Counts_Lund_3R = read.csv("AllCounts_ModernLund_Chr3R.txt", header=FALSE, sep='\t')
Counts_1800_3R = read.csv("AllCounts_Nineteenth_Chr3R.txt", header=FALSE, sep='\t')
Counts_1900_3R = read.csv("AllCounts_Twentieth_Chr3R.txt", header=FALSE, sep='\t')

Counts_FR_3L = read.csv("AllCounts_Lyon_Chr3L.txt", header=FALSE, sep='\t')
Counts_Lund_3L = read.csv("AllCounts_ModernLund_Chr3L.txt", header=FALSE, sep='\t')
Counts_1800_3L = read.csv("AllCounts_Nineteenth_Chr3L.txt", header=FALSE, sep='\t')
Counts_1900_3L = read.csv("AllCounts_Twentieth_Chr3L.txt", header=FALSE, sep='\t')


Counts_FR_2R = read.csv("AllCounts_Lyon_Chr2R.txt", header=FALSE, sep='\t')
Counts_Lund_2R = read.csv("AllCounts_ModernLund_Chr2R.txt", header=FALSE, sep='\t')
Counts_1800_2R = read.csv("AllCounts_Nineteenth_Chr2R.txt", header=FALSE, sep='\t')
Counts_1900_2R = read.csv("AllCounts_Twentieth_Chr2R.txt", header=FALSE, sep='\t')
#

Counts_FR_2L[Kapun_Coords_2Lt,]
Counts_Lund_2L[Kapun_Coords_2Lt,]
Counts_1800_2L[Kapun_Coords_2Lt,]
Counts_1900_2L[Kapun_Coords_2Lt,]

C2Lt = Counts_1900_2L[Kapun_Coords_2Lt,]
length(which(minor_count(C2Lt)==0))
mean(minor_freq(C2Lt),na.rm=TRUE)
median(minor_freq(C2Lt), na.rm=TRUE)
meaningful_mean(minor_freq(C2Lt))
# 3 of 16 missing, 5.4% overall frequency, 6.64% for sites present (median 6.25%)
# mean rowsums counts 1900: 10.5

C2Lt = Counts_1800_2L[Kapun_Coords_2Lt,]
length(which(minor_count(C2Lt)==0))
mean(minor_freq(C2Lt),na.rm=TRUE)
median(minor_freq(C2Lt), na.rm=TRUE)
meaningful_mean(minor_freq(C2Lt))
# 0
# mean rowsums counts 1800: 8.84

C2Lt = Counts_FR_2L[Kapun_Coords_2Lt,]
length(which(minor_count(C2Lt)==0))
mean(minor_freq(C2Lt),na.rm=TRUE)
median(minor_freq(C2Lt), na.rm=TRUE)
meaningful_mean(minor_freq(C2Lt))
# all 16 present, mean = 7.97%, median = 8.02 %
# mean rowsums 177.2

C2Lt = Counts_Lund_2L[Kapun_Coords_2Lt,]
length(which(minor_count(C2Lt)==0))
mean(minor_freq(C2Lt),na.rm=TRUE)
median(minor_freq(C2Lt), na.rm=TRUE)
meaningful_mean(minor_freq(C2Lt))
# all 16 present, mean 12.75% median 12.03%
# mean rowsums 122.69


Counts_FR_3L[Kapun_Coords_3LP,]
Counts_Lund_3L[Kapun_Coords_3LP,]
Counts_1800_3L[Kapun_Coords_3LP,]
Counts_1900_3L[Kapun_Coords_3LP,]


C3LP = Counts_1900_3L[Kapun_Coords_3LP,]
length(which(minor_count(C3LP)==0))
mean(minor_freq(C3LP),na.rm=TRUE)
median(minor_freq(C3LP), na.rm=TRUE)
meaningful_mean(minor_freq(C3LP))
# freq 0
# mean rowsums 3L 9.22


C3LP = Counts_1800_3L[Kapun_Coords_3LP,]
length(which(minor_count(C3LP)==0))
mean(minor_freq(C3LP),na.rm=TRUE)
median(minor_freq(C3LP), na.rm=TRUE)
meaningful_mean(minor_freq(C3LP))
# 72 out of 73 missing, 1 present is an error (freq 0.0012, single present freq = 0.0909 )
which(minor_count(C3LP)>0)
# 3145702
# mean rowsums 9.73

C3LP = Counts_FR_3L[Kapun_Coords_3LP,]
length(which(minor_count(C3LP)==0))
mean(minor_freq(C3LP),na.rm=TRUE)
median(minor_freq(C3LP), na.rm=TRUE)
meaningful_mean(minor_freq(C3LP))
# none missing freq 6.13%, median 6.32%
# mean rowsums 177.22

C3LP = Counts_Lund_3L[Kapun_Coords_3LP,]
length(which(minor_count(C3LP)==0))
mean(minor_freq(C3LP),na.rm=TRUE)
median(minor_freq(C3LP), na.rm=TRUE)
meaningful_mean(minor_freq(C3LP))
# 71 missing, freq 0.00102, non-missing 3.57%
# 3251643 5399565
# mean rowsums 128.74

Counts_FR_2R[Kapun_Coords_2RNs,]
Counts_Lund_2R[Kapun_Coords_2RNs,]
Counts_1800_2R[Kapun_Coords_2RNs,]
Counts_1900_2R[Kapun_Coords_2RNs,]

C2RNs = Counts_1900_2L[Kapun_Coords_2RNs,]
length(which(minor_count(C2RNs)==0))
mean(minor_freq(C2RNs),na.rm=TRUE)
median(minor_freq(C2RNs), na.rm=TRUE)
meaningful_mean(minor_freq(C2RNs))
# 0
# mean rowsums 12.10

C2RNs = Counts_1800_2L[Kapun_Coords_2RNs,]
length(which(minor_count(C2RNs)==0))
mean(minor_freq(C2RNs),na.rm=TRUE)
median(minor_freq(C2RNs), na.rm=TRUE)
meaningful_mean(minor_freq(C2RNs))
# 66 out of 67 missing freq 0.002
3251643 5399565
# mean rowsums 9.43

C2RNs = Counts_FR_2L[Kapun_Coords_2RNs,]
length(which(minor_count(C2RNs)==0))
mean(minor_freq(C2RNs),na.rm=TRUE)
median(minor_freq(C2RNs), na.rm=TRUE)
meaningful_mean(minor_freq(C2RNs))
# 63 out of 67 missing, freq 0.003
# mean rowsums 178

C2RNs = Counts_Lund_2L[Kapun_Coords_2RNs,]
length(which(minor_count(C2RNs)==0))
mean(minor_freq(C2RNs),na.rm=TRUE)
median(minor_freq(C2RNs), na.rm=TRUE)
meaningful_mean(minor_freq(C2RNs))
# 66 out of 67 missing, freq 0.001
# mean rowsums 133



Counts_FR_3R[Kapun_Coords_3RC,]
Counts_Lund_3R[Kapun_Coords_3RC,]
Counts_1800_3R[Kapun_Coords_3RC,]
Counts_1900_3R[Kapun_Coords_3RC,]

C3RC = Counts_1900_3R[Kapun_Coords_3RC,]
length(which(minor_count(C3RC)==0))
mean(minor_freq(C3RC),na.rm=TRUE)
median(minor_freq(C3RC), na.rm=TRUE)
meaningful_mean(minor_freq(C3RC))
# 137 out of 144 missing, freq = 0.006 (12% for those present sites)
which(minor_count(C3RC)>0)
# 16864615 24201208 24374212 24422474 26833261 27033799 27367655
# mean rowsums 13.03

C3RC = Counts_1800_3R[Kapun_Coords_3RC,]
length(which(minor_count(C3RC)==0))
mean(minor_freq(C3RC),na.rm=TRUE)
median(minor_freq(C3RC), na.rm=TRUE)
meaningful_mean(minor_freq(C3RC))
# 142 out of 144 missing, freq = 0.00385 (10% for those present sites)
which(minor_count(C3RC)>0)
# 24693933 26833261
# mean rowsums 10.39

C3RC = Counts_FR_3R[Kapun_Coords_3RC,]
length(which(minor_count(C3RC)==0))
mean(minor_freq(C3RC),na.rm=TRUE)
median(minor_freq(C3RC), na.rm=TRUE)
meaningful_mean(minor_freq(C3RC))
# 5 missing, freq 2.17% (median 1.68%), 2.40% for present sites
# mean rowsums 182.4

C3RC = Counts_Lund_3R[Kapun_Coords_3RC,]
length(which(minor_count(C3RC)==0))
mean(minor_freq(C3RC),na.rm=TRUE)
median(minor_freq(C3RC), na.rm=TRUE)
meaningful_mean(minor_freq(C3RC))
# 90 missing out of 144, 2.03% (4.4% for those present)
which(minor_count(C3RC)>0)
#13114726 16110028 16114832 16145902 16145903 16191928 16864615 16893226 
# 16918188 20924283 20943910 23033890 24342811 24422474 24493367 24693933 
# 25216865 25242597 25315158 25329587 25474612 25489586 25505585 25560925 
# 25567683 25596484 25598648 25599170 25605392 25632833 25647947 25680387 
# 25686401 25686744 25689415 25810959 25822138 25830799 25836339 25865969 
# 25884722 25885398 25892882 25893312 26502830 26553123 26833261 27033799 
# 27050399 27050401 27187114 27189512 27213181 27813043 

#mean rowsums 3R 135.68


Counts_FR_3R[Kapun_Coords_3RMo,]
Counts_Lund_3R[Kapun_Coords_3RMo,]
Counts_1800_3R[Kapun_Coords_3RMo,]
Counts_1900_3R[Kapun_Coords_3RMo,]


C3RMo = Counts_1900_3R[Kapun_Coords_3RMo,]
length(which(minor_count(C3RMo)==0))
mean(minor_freq(C3RMo),na.rm=TRUE)
median(minor_freq(C3RMo), na.rm=TRUE)
meaningful_mean(minor_freq(C3RMo))
# 138 out of 150 missing, freq = 1.63% (12.3% for non-missing)
which(minor_count(C3RMo)>0)
# 15955370 16840241 17183342 17653963 17673637 17833454 17915717 18405781 19690483 20102331 23589504 24757430 

C3RMo = Counts_1800_3R[Kapun_Coords_3RMo,]
length(which(minor_count(C3RMo)==0))
mean(minor_freq(C3RMo),na.rm=TRUE)
median(minor_freq(C3RMo), na.rm=TRUE)
meaningful_mean(minor_freq(C3RMo))
# 142 out of 150 missing, freq = 0.731% (10.3% for non-missing)
which(minor_count(C3RMo)>0)
# 16840241 17183342 17653963 17673637 17833454 19690483 22035252 25065632

C3RMo = Counts_FR_3R[Kapun_Coords_3RMo,]
length(which(minor_count(C3RMo)==0))
mean(minor_freq(C3RMo),na.rm=TRUE)
median(minor_freq(C3RMo), na.rm=TRUE)
meaningful_mean(minor_freq(C3RMo))
# 0 missing, freq = 4.84%

C3RMo = Counts_Lund_3R[Kapun_Coords_3RMo,]
length(which(minor_count(C3RMo)==0))
mean(minor_freq(C3RMo),na.rm=TRUE)
median(minor_freq(C3RMo), na.rm=TRUE)
meaningful_mean(minor_freq(C3RMo))
# 139 missing, freq 0.58% (7.69% for those present)
which(minor_count(C3RMo)>0)
# 16840241 17183342 17653963 17673637 17775264 17871386 20102331 22035252

Counts_FR_3R[Kapun_Coords_3RPayne,]
Counts_Lund_3R[Kapun_Coords_3RPayne,]
Counts_1800_3R[Kapun_Coords_3RPayne,]
Counts_1900_3R[Kapun_Coords_3RPayne,]

C3RPayne = Counts_1900_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(C3RPayne)==0))
mean(minor_freq(C3RPayne),na.rm=TRUE)
median(minor_freq(C3RPayne), na.rm=TRUE)
meaningful_mean(minor_freq(C3RPayne))
# 0

C3RPayne = Counts_1800_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(C3RPayne)==0))
mean(minor_freq(C3RPayne),na.rm=TRUE)
median(minor_freq(C3RPayne), na.rm=TRUE)
meaningful_mean(minor_freq(C3RPayne))
# 18 of 19 missing, freq = 0.004, freq of present site 7.69%
which(minor_count(C3RPayne)>0)
# 20567659

C3RPayne = Counts_FR_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(C3RPayne)==0))
mean(minor_freq(C3RPayne),na.rm=TRUE)
median(minor_freq(C3RPayne), na.rm=TRUE)
meaningful_mean(minor_freq(C3RPayne))
# 0 missing, freq = 0.1064 (median 0.109)

C3RPayne = Counts_Lund_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(C3RPayne)==0))
mean(minor_freq(C3RPayne),na.rm=TRUE)
median(minor_freq(C3RPayne), na.rm=TRUE)
meaningful_mean(minor_freq(C3RPayne))
# 0 missing, freq = 0.1064 (median 0.109)
# 15 of 19 missing, freq = 0.0072 (median = 0), freq of those present = 0.032
which(minor_count(C3RPayne)>0)
# 12259133 17442150 20575824 20590675 

normalize = function(v){
	return(v/sum(v))
}


cmat = function(Counts_Mat, Coords){
	Counts_Mat[Coords,]
}

minor_allele_count = function(v){
	return(sort(v)[3])
}

minor_allele_freq = function(v){
        vtemp = normalize(v)
	return(sort(vtemp)[3])
	}


minor_freq = function(Inv_Mat){
	return(apply(Inv_Mat, 1, minor_allele_freq))
}

minor_count = function(Inv_Mat){
	return(apply(Inv_Mat, 1, minor_allele_count))
}

meaningful_mean = function(v){
	vnew = v[which(v > 0 & v < 0.30)]
	return(mean(vnew,na.rm=TRUE))
}


## Redo modern Lund using raw counts
setwd("/home/mshpak/Lundflies/VCF/Pooled_Round1")

CF_35_2L = read.csv("CountFile_SRR5647735_2L",header=FALSE,sep='\t')
CF_51_2L = read.csv("CountFile_SRR8439151_2L",header=FALSE,sep='\t')
CF_56_2L = read.csv("CountFile_SRR8439156_2L",header=FALSE,sep='\t')
Counts_Lund_2L = CF_35_2L + CF_51_2L + CF_56_2L
rm(list=c("CF_35_2L", "CF_51_2L", "CF_56_2L"))

CF_35_2R = read.csv("CountFile_SRR5647735_2R",header=FALSE,sep='\t')
CF_51_2R = read.csv("CountFile_SRR8439151_2R",header=FALSE,sep='\t')
CF_56_2R = read.csv("CountFile_SRR8439156_2R",header=FALSE,sep='\t')
Counts_Lund_2R = CF_35_2R + CF_51_2R + CF_56_2R
rm(list=c("CF_35_2R", "CF_51_2R", "CF_56_2R"))

CF_35_3L = read.csv("CountFile_SRR5647735_3L",header=FALSE,sep='\t')
CF_51_3L = read.csv("CountFile_SRR8439151_3L",header=FALSE,sep='\t')
CF_56_3L = read.csv("CountFile_SRR8439156_3L",header=FALSE,sep='\t')
Counts_Lund_3L = CF_35_3L + CF_51_3L + CF_56_3L
rm(list=c("CF_35_3L", "CF_51_3L", "CF_56_3L"))

CF_35_3R = read.csv("CountFile_SRR5647735_3R",header=FALSE,sep='\t')
CF_51_3R = read.csv("CountFile_SRR8439151_3R",header=FALSE,sep='\t')
CF_56_3R = read.csv("CountFile_SRR8439156_3R",header=FALSE,sep='\t')
Counts_Lund_3R = CF_35_3R + CF_51_3R + CF_56_3R
rm(list=c("CF_35_3R", "CF_51_3R", "CF_56_3R"))

C2Lt = Counts_Lund_2L[Kapun_Coords_2Lt,]
length(which(minor_count(C2Lt)==0))
mean(minor_freq(C2Lt),na.rm=TRUE)
median(minor_freq(C2Lt), na.rm=TRUE)
# 0.1194282
meaningful_mean(minor_freq(C2Lt))
# 0.1266068 (for both)


# probably absent: 43 out of 67 are 0
C2RNs = Counts_Lund_2R[Kapun_Coords_2RNs,]
length(which(minor_count(C2RNs)==0))
mean(minor_freq(C2RNs),na.rm=TRUE)
median(minor_freq(C2RNs), na.rm=TRUE)
# 0
meaningful_mean(minor_freq(C2RNs))
# 0.008491402 (raw)
# 0.02264374

#probably present: 14 out of 73 missing
C3LP=Counts_Lund_3L[Kapun_Coords_3LP,]
length(which(minor_count(C3LP)==0))
mean(minor_freq(C3LP),na.rm=TRUE)
median(minor_freq(C3LP), na.rm=TRUE)
# 0.01217044
meaningful_mean(minor_freq(C3LP))
# 0.01267538
# 0.01503859

# probably present - 55 out of 144 missing, 4 of which are due to 0 rows (51 out of 140)
C3Rc = Counts_Lund_3R[Kapun_Coords_3RC,]
length(which(minor_count(C3Rc)==0))
mean(minor_freq(C3Rc),na.rm=TRUE)
median(minor_freq(C3Rc),na.rm=TRUE)
# 0.01846494
meaningful_mean(minor_freq(C3Rc))
# 0.02264374
# 0.03268034


# Probably absent - 120 out of 150 have 0 minor allele count
C3RMo = Counts_Lund_3R[Kapun_Coords_3RMo,]
length(which(minor_count(C3RMo)==0))
#apply(C3RMo, 1, meaningful_mean)
mean(minor_freq(C3RMo),na.rm=TRUE)
# 0.0075009
median(minor_freq(C3RMo),na.rm=TRUE)
# 0ls 
meaningful_mean(minor_freq(C3RMo))
# 0.036754

## Almost certainly present 3 out of 16 missing minor, 4th is a 0 count row
C3RPayne = Counts_Lund_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(C3RPayne)==0))
mean(minor_freq(C3RPayne),na.rm=TRUE)
median(minor_freq(C3RPayne),na.rm=TRUE)
# 0.01198801
meaningful_mean(minor_freq(C3RPayne))
# 0.01479185
# 0.01775023


# create new Lyon File:
F2Lt=Counts_FR_2L[Kapun_Coords_2Lt,]
mean(minor_freq(F2Lt),na.rm=TRUE)
# 0.06908


setwd("/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2L_Only")
list_ls = grep(pattern="Chr2L", x = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2L_Only"))
fr_files = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2L_Only")[list_ls[1:50]]

FR_Counts = read.csv(fr_files[1],header=FALSE,sep='\t')
for(fname in fr_files[2:50]){
	FR_Temp = read.csv(fname, header=FALSE, sep='\t')
	FR_Counts = FR_Counts + FR_Temp
}

F2Lt = FR_Counts[Kapun_Coords_2Lt,]
length(which(minor_count(F2Lt)==0))
mean(minor_freq(F2Lt),na.rm=TRUE)
median(minor_freq(F2Lt),na.rm=TRUE)
# 0.09555691
meaningful_mean(minor_freq(F2Lt))
# 0.09436505



setwd("/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3R_Only")
list_ls = grep(pattern="Chr3R", x = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3R_Only"))
fr_files = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3R_Only")[list_ls[1:50]]

FR_Counts_3R = read.csv(fr_files[1],header=FALSE,sep='\t')
for(fname in fr_files[2:50]){
	print(fname)
	FR_Temp = read.csv(fname, header=FALSE, sep='\t')
	FR_Counts_3R = FR_Counts_3R + FR_Temp
}
#

setwd("/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3L_Only")
list_ls = grep(pattern="Chr3L", x = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3L_Only"))
fr_files = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_3L_Only")[list_ls[1:50]]

FR_Counts_3L = read.csv(fr_files[1],header=FALSE,sep='\t')
for(fname in fr_files[2:50]){
	print(fname)
	FR_Temp = read.csv(fname, header=FALSE, sep='\t')
	FR_Counts_3L = FR_Counts_3L + FR_Temp
}

#
setwd("/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2R_Only")
list_ls = grep(pattern="Chr2R", x = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2R_Only"))
fr_files = list.files(path="/raid10/mshpak/MuseumFlies/IndivCounts/Diploid/FR_2R_Only")[list_ls[1:50]]

FR_Counts_2R = read.csv(fr_files[1],header=FALSE,sep='\t')
for(fname in fr_files[2:50]){
	FR_Temp = read.csv(fname, header=FALSE, sep='\t')
	FR_Counts_2R = FR_Counts_2R + FR_Temp
}
#



# 66 out of 67 missing
F2RNs = FR_Counts_2R[Kapun_Coords_2RNs,]
length(which(minor_count(F2RNs)==0))
mean(minor_freq(F2RNs),na.rm=TRUE)
median(minor_freq(F2RNs),na.rm=TRUE)
# 0
meaningful_mean(minor_freq(F2RNs))
# 0.004797441 (raw)

F3LP=FR_Counts_3L[Kapun_Coords_3LP,]
length(which(minor_count(F3LP)==0))
mean(minor_freq(F3LP),na.rm=TRUE)
# 0.0430728
median(minor_freq(F3LP),na.rm=TRUE)
# 0.04109589
meaningful_mean(minor_freq(F3LP))
# 0.0430728

# probably present - 58 out of 144 missing
F3Rc = FR_Counts_3R[Kapun_Coords_3RC,]
length(which(minor_count(F3Rc)==0))
mean(minor_freq(F3Rc),na.rm=TRUE)
median(minor_freq(F3Rc),na.rm=TRUE)
#0.01639344
meaningful_mean(minor_freq(F3Rc))
# 0.02803489
# 0.04218131


# Probably present - 32 out of 150 have 0 minor allele count
F3RMo = FR_Counts_3R[Kapun_Coords_3RMo,]
length(which(minor_count(F3RMo)==0))
#apply(C3RMo, 1, meaningful_mean)
mean(minor_freq(F3RMo),na.rm=TRUE)
# 0.01756779
median(minor_freq(F3RMo),na.rm=TRUE)
#0.015625
meaningful_mean(minor_freq(F3RMo))
# 0.02233193

## present 0 out of 16 missing minor, 4th is a 0 count row
F3RPayne = FR_Counts_3R[Kapun_Coords_3RPayne,]
length(which(minor_count(F3RPayne)==0))
mean(minor_freq(F3RPayne),na.rm=TRUE)
median(minor_freq(F3RPayne),na.rm=TRUE)
# 0.1060606
meaningful_mean(minor_freq(F3RPayne))
# 0.09995837
# 0.09995837


### probability of absence of 3LP, 3RC, and 3RPayne from museum samples due to error (assuming actual frequencies = Lund 2015)
# maximum number of sites per inversion-linked loci
# 1933: 2Lt: 16, 3LP: 13, 3RC: 23, 3RP: 18, 
# 1800: 2Lt 13, 3LP: 11, 3RC: 14, 3RP: 13, 
# Combined: 3LT 29, 3LP: 24, 3RC: 36, 3RP 31
